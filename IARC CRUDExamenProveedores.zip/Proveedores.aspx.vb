Partial Class Proveedores
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            CargarDatos()
        End If
    End Sub

    Private Sub CargarDatos()
        GridView1.DataSource = DataAccess.ObtenerProveedores()
        GridView1.DataBind()
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(sender As Object, e As EventArgs)
        Dim fila = GridView1.SelectedRow
        lblId.Text = fila.Cells(0).Text
        txtEmpresa.Text = fila.Cells(1).Text
        txtContacto.Text = fila.Cells(2).Text
        txtTelefono.Text = fila.Cells(3).Text
    End Sub

    Protected Sub btnGuardar_Click(sender As Object, e As EventArgs)
        If lblId.Text = "" Then
            DataAccess.InsertarProveedor(txtEmpresa.Text, txtContacto.Text, txtTelefono.Text)
        Else
            DataAccess.ActualizarProveedor(Integer.Parse(lblId.Text), txtEmpresa.Text, txtContacto.Text, txtTelefono.Text)
        End If
        LimpiarFormulario()
        CargarDatos()
    End Sub

    Protected Sub btnCancelar_Click(sender As Object, e As EventArgs)
        LimpiarFormulario()
    End Sub

    Private Sub LimpiarFormulario()
        lblId.Text = ""
        txtEmpresa.Text = ""
        txtContacto.Text = ""
        txtTelefono.Text = ""
        GridView1.SelectedIndex = -1
    End Sub

    Protected Sub GridView1_RowDeleting(sender As Object, e As GridViewDeleteEventArgs)
        Dim id = Convert.ToInt32(GridView1.DataKeys(e.RowIndex).Value)
        DataAccess.EliminarProveedor(id)
        CargarDatos()
    End Sub
End Class