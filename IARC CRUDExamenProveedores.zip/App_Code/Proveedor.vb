Public Class Proveedor
    Public Property ProveedorId As Integer
    Public Property NombreEmpresa As String
    Public Property Contacto As String
    Public Property Telefono As String

    Public Sub New(id As Integer, nombreEmpresa As String, contacto As String, telefono As String)
        ProveedorId = id
        NombreEmpresa = nombreEmpresa
        Contacto = contacto
        Telefono = telefono
    End Sub
End Class