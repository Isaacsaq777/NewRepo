Imports System.Data.SqlClient

Public Class DataAccess
    Private Shared connectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("MiConexion").ConnectionString

    Public Shared Function ObtenerProveedores() As DataTable
        Dim tabla As New DataTable()
        Using con As New SqlConnection(connectionString)
            Dim cmd As New SqlCommand("SELECT * FROM Proveedores", con)
            con.Open()
            tabla.Load(cmd.ExecuteReader())
        End Using
        Return tabla
    End Function

    Public Shared Sub InsertarProveedor(nombreEmpresa As String, contacto As String, telefono As String)
        Using con As New SqlConnection(connectionString)
            Dim cmd As New SqlCommand("INSERT INTO Proveedores (NombreEmpresa, Contacto, Telefono) VALUES (@NombreEmpresa, @Contacto, @Telefono)", con)
            cmd.Parameters.AddWithValue("@NombreEmpresa", nombreEmpresa)
            cmd.Parameters.AddWithValue("@Contacto", contacto)
            cmd.Parameters.AddWithValue("@Telefono", telefono)
            con.Open()
            cmd.ExecuteNonQuery()
        End Using
    End Sub

    Public Shared Sub ActualizarProveedor(id As Integer, nombreEmpresa As String, contacto As String, telefono As String)
        Using con As New SqlConnection(connectionString)
            Dim cmd As New SqlCommand("UPDATE Proveedores SET NombreEmpresa=@NombreEmpresa, Contacto=@Contacto, Telefono=@Telefono WHERE ProveedorId=@ProveedorId", con)
            cmd.Parameters.AddWithValue("@ProveedorId", id)
            cmd.Parameters.AddWithValue("@NombreEmpresa", nombreEmpresa)
            cmd.Parameters.AddWithValue("@Contacto", contacto)
            cmd.Parameters.AddWithValue("@Telefono", telefono)
            con.Open()
            cmd.ExecuteNonQuery()
        End Using
    End Sub

    Public Shared Sub EliminarProveedor(id As Integer)
        Using con As New SqlConnection(connectionString)
            Dim cmd As New SqlCommand("DELETE FROM Proveedores WHERE ProveedorId=@ProveedorId", con)
            cmd.Parameters.AddWithValue("@ProveedorId", id)
            con.Open()
            cmd.ExecuteNonQuery()
        End Using
    End Sub
End Class