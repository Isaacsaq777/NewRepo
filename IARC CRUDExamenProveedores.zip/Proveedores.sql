CREATE DATABASE ExamenProveedores;
GO
USE ExamenProveedores;
GO
CREATE TABLE Proveedores (
    ProveedorId INT PRIMARY KEY IDENTITY(1,1),
    NombreEmpresa NVARCHAR(100) NOT NULL,
    Contacto NVARCHAR(100) NOT NULL,
    Telefono NVARCHAR(20) NOT NULL
);