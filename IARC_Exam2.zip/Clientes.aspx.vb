Imports System.Text.RegularExpressions

Partial Class Clientes
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("Usuario") Is Nothing Then
            Response.Redirect("Login.aspx")
            Return
        End If
        If Not IsPostBack Then
            CargarGrid()
            LimpiarFormulario()
        End If
    End Sub

    Private Sub CargarGrid()
        Dim dt = ClienteRepository.GetAll()
        gvClientes.DataSource = dt
        gvClientes.DataBind()
    End Sub

    Protected Sub gvClientes_SelectedIndexChanged(sender As Object, e As EventArgs) Handles gvClientes.SelectedIndexChanged
        Dim id = Convert.ToInt32(gvClientes.SelectedDataKey.Value)
        Dim c = ClienteRepository.GetById(id)
        If c IsNot Nothing Then
            hfId.Value = c.ClienteId.ToString()
            txtNombre.Text = c.Nombre
            txtApellidos.Text = c.Apellidos
            txtEmail.Text = c.Email
            txtTelefono.Text = c.Telefono
        End If
    End Sub

    Protected Sub gvClientes_RowDeleting(sender As Object, e As GridViewDeleteEventArgs) Handles gvClientes.RowDeleting
        Dim id = Convert.ToInt32(gvClientes.DataKeys(e.RowIndex).Value)
        ClienteRepository.Delete(id)
        CargarGrid()
    End Sub

    Protected Sub gvClientes_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles gvClientes.RowEditing
        gvClientes.EditIndex = e.NewEditIndex
        CargarGrid()
    End Sub

    Protected Sub gvClientes_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles gvClientes.RowUpdating
        Dim id = Convert.ToInt32(gvClientes.DataKeys(e.RowIndex).Value)
        Dim row As GridViewRow = gvClientes.Rows(e.RowIndex)
        Dim c As New Cliente()
        c.ClienteId = id
        c.Nombre = CType(row.Cells(1).Controls(0), TextBox).Text
        c.Apellidos = CType(row.Cells(2).Controls(0), TextBox).Text
        c.Email = CType(row.Cells(3).Controls(0), TextBox).Text
        c.Telefono = CType(row.Cells(4).Controls(0), TextBox).Text
        ClienteRepository.Update(c)
        gvClientes.EditIndex = -1
        CargarGrid()
    End Sub

    Protected Sub gvClientes_RowCancelingEdit(sender As Object, e As EventArgs) Handles gvClientes.RowCancelingEdit
        gvClientes.EditIndex = -1
        CargarGrid()
    End Sub

    Protected Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles btnGuardar.Click
        Dim nombre = txtNombre.Text.Trim()
        Dim apellidos = txtApellidos.Text.Trim()
        Dim email = txtEmail.Text.Trim()
        Dim telefono = txtTelefono.Text.Trim()

        If nombre = "" Or apellidos = "" Or telefono = "" Then
            lblMsg.Text = "Nombre, Apellidos y Teléfono son obligatorios"
            Return
        End If

        Dim pattern = "^[^@\s]+@[^@\s]+\.[^@\s]+$"
        If Not Regex.IsMatch(email, pattern) Then
            lblMsg.Text = "Email inválido"
            Return
        End If

        Dim c As New Cliente()
        c.Nombre = nombre
        c.Apellidos = apellidos
        c.Email = email
        c.Telefono = telefono

        If String.IsNullOrEmpty(hfId.Value) Then
            ClienteRepository.Insert(c)
        Else
            c.ClienteId = Convert.ToInt32(hfId.Value)
            ClienteRepository.Update(c)
        End If

        LimpiarFormulario()
        CargarGrid()
    End Sub

    Protected Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        LimpiarFormulario()
        gvClientes.SelectedIndex = -1
    End Sub

    Private Sub LimpiarFormulario()
        hfId.Value = ""
        txtNombre.Text = ""
        txtApellidos.Text = ""
        txtEmail.Text = ""
        txtTelefono.Text = ""
        lblMsg.Text = ""
    End Sub
End Class