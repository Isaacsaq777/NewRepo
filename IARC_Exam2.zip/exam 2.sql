-- 1. Crear la base de datos
CREATE DATABASE ClientesDB;
GO

-- 2. Usar la base de datos
USE ClientesDB;
GO

-- 3. Crear la tabla Clientes
CREATE TABLE Clientes (
    ClienteId INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(50) NOT NULL,
    Apellidos NVARCHAR(50) NOT NULL,
    Telefono NVARCHAR(20) NOT NULL,
    Email NVARCHAR(100) NOT NULL
);
GO

-- 4. Insertar datos de ejemplo
INSERT INTO Clientes (Nombre, Apellidos, Telefono, Email) VALUES
('Juan', 'P�rez', '8888-1111', 'juan.perez@example.com'),
('Mar�a', 'L�pez', '8888-2222', 'maria.lopez@example.com'),
('Carlos', 'Ram�rez', '8888-3333', 'carlos.ramirez@example.com');
GO

-- 5. Crear tabla de usuarios para login
CREATE TABLE Usuarios (
    UsuarioId INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(50) NOT NULL
);
GO

-- 6. Insertar usuarios de prueba
INSERT INTO Usuarios (Username, Password) VALUES
('admin', '1234'),
('usuario', 'abcd');
GO
