CREATE DATABASE ClientesDB;
GO
USE ClientesDB;
GO
CREATE TABLE Usuarios (
    UsuarioId INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50) NOT NULL,
    Password NVARCHAR(50) NOT NULL
);
CREATE TABLE Clientes (
    ClienteId INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(100) NOT NULL,
    Apellidos NVARCHAR(150) NOT NULL,
    Email NVARCHAR(150) NOT NULL,
    Telefono NVARCHAR(20) NOT NULL
);
INSERT INTO Usuarios (Username, Password) VALUES ('admin','1234'), ('usuario','abcd');
INSERT INTO Clientes (Nombre, Apellidos, Email, Telefono) VALUES
('Juan Pérez','González','juan.perez@ejemplo.cr','8888-1234'),
('María López','Fernández','maria.lopez@ejemplo.cr','8888-5678');