Imports System.Data
Imports System.Data.SqlClient

Public Class ClienteRepository
    Public Shared Function GetAll() As DataTable
        Dim dt As New DataTable()
        Dim sql As String = "SELECT ClienteId, Nombre, Apellidos, Email, Telefono FROM Clientes ORDER BY ClienteId DESC"
        Using cn As New SqlConnection(DatabaseHelper.ConnectionString)
            Using cmd As New SqlCommand(sql, cn)
                Using da As New SqlDataAdapter(cmd)
                    da.Fill(dt)
                End Using
            End Using
        End Using
        Return dt
    End Function

    Public Shared Function GetById(id As Integer) As Cliente
        Dim sql As String = "SELECT ClienteId, Nombre, Apellidos, Email, Telefono FROM Clientes WHERE ClienteId=@Id"
        Using cn As New SqlConnection(DatabaseHelper.ConnectionString)
            Using cmd As New SqlCommand(sql, cn)
                cmd.Parameters.AddWithValue("@Id", id)
                cn.Open()
                Using rdr As SqlDataReader = cmd.ExecuteReader()
                    If rdr.Read() Then
                        Dim c As New Cliente()
                        c.ClienteId = Convert.ToInt32(rdr("ClienteId"))
                        c.Nombre = rdr("Nombre").ToString()
                        c.Apellidos = rdr("Apellidos").ToString()
                        c.Email = rdr("Email").ToString()
                        c.Telefono = rdr("Telefono").ToString()
                        Return c
                    End If
                End Using
            End Using
        End Using
        Return Nothing
    End Function

    Public Shared Function Insert(c As Cliente) As Boolean
        Dim sql As String = "INSERT INTO Clientes (Nombre, Apellidos, Email, Telefono) VALUES (@Nombre, @Apellidos, @Email, @Telefono)"
        Using cn As New SqlConnection(DatabaseHelper.ConnectionString)
            Using cmd As New SqlCommand(sql, cn)
                cmd.Parameters.AddWithValue("@Nombre", c.Nombre)
                cmd.Parameters.AddWithValue("@Apellidos", c.Apellidos)
                cmd.Parameters.AddWithValue("@Email", c.Email)
                cmd.Parameters.AddWithValue("@Telefono", c.Telefono)
                cn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function

    Public Shared Function Update(c As Cliente) As Boolean
        Dim sql As String = "UPDATE Clientes SET Nombre=@Nombre, Apellidos=@Apellidos, Email=@Email, Telefono=@Telefono WHERE ClienteId=@Id"
        Using cn As New SqlConnection(DatabaseHelper.ConnectionString)
            Using cmd As New SqlCommand(sql, cn)
                cmd.Parameters.AddWithValue("@Nombre", c.Nombre)
                cmd.Parameters.AddWithValue("@Apellidos", c.Apellidos)
                cmd.Parameters.AddWithValue("@Email", c.Email)
                cmd.Parameters.AddWithValue("@Telefono", c.Telefono)
                cmd.Parameters.AddWithValue("@Id", c.ClienteId)
                cn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function

    Public Shared Function Delete(id As Integer) As Boolean
        Dim sql As String = "DELETE FROM Clientes WHERE ClienteId=@Id"
        Using cn As New SqlConnection(DatabaseHelper.ConnectionString)
            Using cmd As New SqlCommand(sql, cn)
                cmd.Parameters.AddWithValue("@Id", id)
                cn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function
End Class