Public Class Cliente
    Inherits Persona
    Public Property ClienteId As Integer
End Class