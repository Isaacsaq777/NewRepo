Public Class Persona
    Public Property Nombre As String
    Public Property Apellidos As String
    Public Property Email As String
    Public Property Telefono As String
End Class