Imports System.Data.SqlClient

Partial Class Login
    Inherits System.Web.UI.Page

    Protected Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim user = txtUser.Text.Trim()
        Dim pass = txtPass.Text.Trim()
        If user = "" Or pass = "" Then
            lblMsg.Text = "Complete ambos campos"
            Return
        End If
        Dim sql As String = "SELECT COUNT(*) FROM Usuarios WHERE Username=@u AND Password=@p"
        Using cn As New SqlConnection(DatabaseHelper.ConnectionString)
            Using cmd As New SqlCommand(sql, cn)
                cmd.Parameters.AddWithValue("@u", user)
                cmd.Parameters.AddWithValue("@p", pass)
                cn.Open()
                Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                If count > 0 Then
                    Session("Usuario") = user
                    Response.Redirect("Clientes.aspx")
                Else
                    lblMsg.Text = "Credenciales inválidas"
                End If
            End Using
        End Using
    End Sub
End Class